﻿using Microsoft.Data.SqlClient;
using Milestone_247.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Milestone_247.Services.Game
{
    public class GameDAO
    {
        public static String CONNECTION_STRING = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=cst-247;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public Board findGrid(Board board)
        {
            
            try
            {
                // Setup SELECT query with parameters
                string query = "SELECT * FROM dbo.grids WHERE USERID=@id";
                int user = 1;

                // Create connection and command
                using (SqlConnection cn = new SqlConnection(CONNECTION_STRING))
                using (SqlCommand cmd = new SqlCommand(query, cn))
                {
                    
                    // Set query parameters and their values
                    cmd.Parameters.Add("@id", SqlDbType.Int, 11).Value = user;


                    // Open the connection
                    cn.Open();

                    // Using a DataReader see if query returns any rows
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        int ID = int.Parse(reader["ID"].ToString());
                        int rows = int.Parse(reader["ROWS"].ToString());
                        int cols = int.Parse(reader["COLS"].ToString());
                        int USER_ID = int.Parse(reader["USERID"].ToString());
                        int clicks = int.Parse(reader["CLICKS"].ToString());

                      
                    }

                    // Close the connection
                    cn.Close();
                }

            }
            catch (SqlException e)
            {
                throw e;
            }


            if (board != null)
            {
                try
                {
                    // Setup SELECT query with parameters
                    string query = "SELECT * FROM dbo.cells WHERE GRIDID=@id";
                    int user = 1;
                    // Create connection and command
                    using (SqlConnection cn = new SqlConnection(CONNECTION_STRING))
                    using (SqlCommand cmd = new SqlCommand(query, cn))
                    {
                        // Set query parameters and their values
                        cmd.Parameters.Add("@id", SqlDbType.Int, 11).Value = user;


                        // Open the connection
                        cn.Open();

                        // Using a DataReader see if query returns any rows
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            int ID = int.Parse(reader["ID"].ToString());
                            int x = int.Parse(reader["X"].ToString());
                            int y = int.Parse(reader["Y"].ToString());
                            Boolean bomb = Boolean.Parse(reader["BOMB"].ToString());
                            Boolean visited = Boolean.Parse(reader["VISITED"].ToString());
                            int live = int.Parse(reader["LIVENEIGHBORS"].ToString());
                            int gridId = int.Parse(reader["GRIDID"].ToString());

                            ButtonModel c = new ButtonModel(x, y);
                            c.id = ID;
                            c.Live = bomb;
                            c.Visited = visited;
                            c.Neighbors = live;
                            

                        }

                        // Close the connection
                        cn.Close();
                    }

                }
                catch (SqlException e)
                {
                    // TODO: should log exception and then throw a custom exception
                    throw e;
                }
            }

            return board;


        }
        public void createGrid(Board board)
        {
            try
            {
                // Setup INSERT query with parameters
                string query = "INSERT INTO dbo.cells (X, Y, BOMB, VISITED, LIVENEIGHBORS, GRIDID) " +
                    "VALUES (@x, @y, @bomb, @visited, @live, @grid)";

                // Create connection and command
                for (int y = 0; y < board.Size; y++)
                {
                    for (int x = 0; x < board.Size; x++)
                    {
                        using (SqlConnection cn = new SqlConnection(CONNECTION_STRING))
                        using (SqlCommand cmd = new SqlCommand(query, cn))
                        {
                            // Set query parameters and their values
                            cmd.Parameters.Add("@x", SqlDbType.Int, 11).Value = board.gameBoard[x,y].Row;
                            cmd.Parameters.Add("@y", SqlDbType.Int, 11).Value = board.gameBoard[x, y].Column;
                            cmd.Parameters.Add("@bomb", SqlDbType.Bit).Value = board.gameBoard[x, y].Live;
                            cmd.Parameters.Add("@visited", SqlDbType.Bit).Value = board.gameBoard[x, y].Visited;
                            cmd.Parameters.Add("@live", SqlDbType.Int, 11).Value = board.gameBoard[x, y].Neighbors;

                            // Open the connection, execute INSERT, and close the connection
                            cn.Open();
                            int rows = cmd.ExecuteNonQuery();
                            cn.Close();



                        }
                    }
                }

            }
            catch (SqlException e)
            {
                // TODO: should log exception and then throw a custom exception
                throw e;
            }



        }
    }
}
