﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
//$(function () {
//    console.log("page is ready");

//    $(document).on("click",".game-button", function (event) {
//        event.preventDefault();

//        var buttonNumber = $(this).val();
//        console.log("Button " + buttonNumber + " was clicked");
//        doButtonUpdate(buttonNumber);
//    })

//    function doButtonUpdate(buttonNumber) {
//        $.ajax({
//            dataType: "text",
//            method: "POST",
//            url: '/Minesweeper/ShowOneButton',
//            data: {
//                "buttonNumber": buttonNumber
//            },
//            success: function (data) {
//                console.log(data);
//                $("#" + buttonNumber).html(data);
//            }
//        })
//    }
//})