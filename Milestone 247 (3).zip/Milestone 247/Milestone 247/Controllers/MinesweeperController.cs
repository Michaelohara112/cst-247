﻿using Microsoft.AspNetCore.Mvc;
using Milestone_247.Models;
using Milestone_247.Services.Game;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Milestone_247.Controllers
{
    public class MinesweeperController : Controller
    {
        //create list of buttons
        static List<ButtonModel> buttons = new List<ButtonModel>();
        public int[,] button = new int[10,  10];

        //Grid size
        const int GRID_SIZE = 10;
        static Board game = new Board(GRID_SIZE);
        static GameDAO data = new GameDAO();
        public IActionResult Index()
        {
            game.DetermineIsLive();
            game.liveNeighbors();
            //Empty the list when the pages loads
            //buttons = new List<ButtonModel>();
            button = new int[GRID_SIZE,  GRID_SIZE];
            //Generates the grid
            for (int i = 0; i < GRID_SIZE; i++)
            {
                for (int j = 0; j < GRID_SIZE; j++)
                {
                    buttons.Add(new ButtonModel(i, j));
                }

            }


            //Send the button list to the index page
            return View("index", game);
        }

        //manage the button click
        public int clicks = 0;
        public IActionResult HandleButtonClick(string buttonNumber)
        {
            clicks++;
            //convert the string to int
            string[] num = buttonNumber.Split(',');
            int bttnRow = int.Parse(num[0]);
            int bttnCol = int.Parse(num[1]);
            game.gameBoard[bttnRow, bttnCol].Visited = true;
            game.FloodFill(bttnRow, bttnCol);
            game.gameOver();
            game.endGame();
            return View("Index", game);

        }

        //public IActionResult ShowOneButton(string buttonNumber)
        //{
        //    //convert the string to int
        //    string[] num = buttonNumber.Split(',');
        //    int bttnRow = int.Parse(num[0]);
        //    int bttnCol = int.Parse(num[1]);
        //    game.gameBoard[bttnRow, bttnCol].Visited = true;
        //    game.FloodFill(bttnRow, bttnCol);
        //    game.gameOver();
        //    game.endGame();
        //    return PartialView("Index", game);
        //}
    }
}
