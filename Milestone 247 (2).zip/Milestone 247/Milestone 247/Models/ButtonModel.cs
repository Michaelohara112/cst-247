﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Milestone_247.Models
{
    public class ButtonModel
    {

        public int id { get; set; }

        public ButtonModel()
        {

        }
        /// <summary>
        /// Contructor to initialize variables
        /// </summary>
        /// <param name="id"></param>
        /// <param name="buttonState"></param>
        public ButtonModel(int id)
        {
            this.id = id;
        }

    }
}
