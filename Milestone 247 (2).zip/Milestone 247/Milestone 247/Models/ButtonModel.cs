﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Milestone_247.Models
{
    public class ButtonModel
    {
        //getters and setters
        public int id { get; set; }
        public int Row { get; set; } //row
        public int Column { get; set; } //column
        public bool Visited { get; set; } //if the square was visited
        public bool Live { get; set; } //if the square was live
        public int Neighbors { get; set; } //neighbor squares


        // Constructor
        public ButtonModel()
        {
            id = -1;
            Row = -1;
            Column = -1;
            Neighbors = 0;
            Visited = false;
            Live = false;
        }
        public ButtonModel(int Row, int Column)
        {
            id = -1;
            this.Row = Row;
            this.Column = Column;
            Neighbors = 0;
            Visited = false;
            Live = false;
        }

    }
}
