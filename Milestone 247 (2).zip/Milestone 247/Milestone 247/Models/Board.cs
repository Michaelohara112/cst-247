﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Milestone_247.Models
{
    public class Board
    {
        public ButtonModel[,] gameBoard { get; set; }
        public int gridSize;
        public int Size { get; set; }

        public Board(int gridSize)
        {
            this.gridSize = gridSize;
            this.Size = gridSize;
            
            //populate board
            gameBoard = new ButtonModel[gridSize, gridSize];
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    gameBoard[i, j] = new ButtonModel();
                }
            }
        }
        private Random random = new Random();
        //added a difficulty to the game
        public void DetermineIsLive()
        {
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    int x = random.Next(0, 100);
                    if (x < 10)
                        gameBoard[i, j].Live = true;
                }
            }
        }
        //Method to determine number of live neighbors

        private int neighbors(int x, int y)
        {
            if (x > -1 && y > -1)
            {
                if (x < gridSize && y < gridSize)
                {
                    if (gameBoard[x, y].Live == true)
                        return 1;
                }
            }
            return 0;
        }
        //Method to print maze to console

        public void liveNeighbors()
        //checks to see if there is a bomb near
        {
            for (int i = 0; i < gameBoard.GetLength(0); i++)
            {
                for (int j = 0; j < gameBoard.GetLength(1); j++)
                {

                    int x = 0;

                    x += neighbors(i - 1, j - 1);
                    x += neighbors(i - 1, j);
                    x += neighbors(i - 1, j + 1);
                    x += neighbors(i, j - 1);
                    x += neighbors(i, j + 1);
                    x += neighbors(i + 1, j - 1);
                    x += neighbors(i + 1, j);
                    x += neighbors(i + 1, j + 1);

                    gameBoard[i, j].Neighbors = x;
                }
            }
        }
        public bool endGame()
        {
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {

                    if (gameBoard[i, j].Visited == false && gameBoard[i, j].Live == false)
                    {
                        return false;
                    }

                }
            }
            return true;
        }
        public bool gameOver()
        {
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {

                    if (gameBoard[i, j].Visited == true && gameBoard[i, j].Live == true)
                    {
                        return true;
                    }

                }
            }
            return false;
        }
        /// <summary>
        /// FloodFills the board until it hits a neighbor that is equal to zero
        /// with collaboration of kayla and mac
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        public void FloodFill(int row, int col)
        {
            if (gameBoard[row, col].Neighbors == 0 && gameBoard[row, col].Live == false && gameBoard[row, col].Visited == true)
            {
                try
                {
                    if (gameBoard[row + 1, col].Visited == false)
                    {
                        //+1 +0 down
                        gameBoard[row + 1, col].Visited = true;
                        FloodFill(row + 1, col);
                    }
                }
                catch
                {

                }
                try
                {
                    if (gameBoard[row + 1, col - 1].Visited == false)
                    {
                        //+1 -1 down left
                        gameBoard[row + 1, col - 1].Visited = true;
                        FloodFill(row + 1, col - 1);
                    }
                }
                catch
                {

                }
                try
                {
                    if (gameBoard[row + 1, col + 1].Visited == false)
                    {
                        //+1 +1 down right
                        gameBoard[row + 1, col + 1].Visited = true;
                        FloodFill(row + 1, col + 1);
                    }
                }
                catch
                {
                }

                try
                {
                    if (gameBoard[row - 1, col].Visited == false)
                    {
                        //-1 +0 up
                        gameBoard[row - 1, col].Visited = true;
                        FloodFill(row - 1, col);
                    }
                }
                catch
                {

                }
                try
                {
                    if (gameBoard[row - 1, col + 1].Visited == false)
                    {
                        //-1 + 1 up right
                        gameBoard[row - 1, col + 1].Visited = true;
                        FloodFill(row - 1, col + 1);
                    }
                }
                catch
                {

                }
                try
                {

                    if (gameBoard[row - 1, col - 1].Visited == false)
                    {
                        //-1 -1 up left
                        gameBoard[row - 1, col - 1].Visited = true;
                        FloodFill(row - 1, col - 1);
                    }
                }
                catch { }
                try
                {


                    if (gameBoard[row, col + 1].Visited == false)
                    {
                        // 0 +1 right
                        gameBoard[row, col + 1].Visited = true;
                        FloodFill(row, col + 1);
                    }
                }
                catch { }
                try
                {
                    if (gameBoard[row, col - 1].Visited == false)
                    {
                        //0 - 1 left
                        gameBoard[row, col - 1].Visited = true;
                        FloodFill(row, col - 1);
                    }
                }
                catch { }

            }

        }
    }
}