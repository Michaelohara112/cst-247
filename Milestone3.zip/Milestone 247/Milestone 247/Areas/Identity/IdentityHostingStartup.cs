﻿using System;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Milestone_247.Areas.Identity.Data;
using Milestone_247.Data;

[assembly: HostingStartup(typeof(Milestone_247.Areas.Identity.IdentityHostingStartup))]
namespace Milestone_247.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
                services.AddDbContext<Milestone_247Context>(options =>
                    options.UseSqlServer(
                        context.Configuration.GetConnectionString("Milestone_247ContextConnection")));

                services.AddDefaultIdentity<Milestone_247User>(options => options.SignIn.RequireConfirmedAccount = true)
                    .AddEntityFrameworkStores<Milestone_247Context>();
            });
        }
    }
}