﻿using Microsoft.AspNetCore.Mvc;
using Milestone_247.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Milestone_247.Controllers
{
    public class MinesweeperController : Controller
    {
        //create list of buttons
        static List<ButtonModel> buttons = new List<ButtonModel>();
        //Define a random obj
        Random random = new Random();
        //Grid size
        const int GRID_SIZE = 100;
        public IActionResult Index()
        {


            //Empty the list when the pages loads
            buttons = new List<ButtonModel>();

            //Generate some new buttons. Randommly chose color values
            for (int bttn = 0; bttn < GRID_SIZE; bttn++)
            {
                //Random will select a number less than 5
                buttons.Add(new ButtonModel(bttn));
            }


            //Send the button list to the index page
            return View("index", buttons);
        }

        //manage the button click
        public IActionResult HandleButtonClick(string buttonNumber)
        {
            //convert the string to int
            int bttnInt = int.Parse(buttonNumber);
            return View("Index", buttons);
        }
    }
}
